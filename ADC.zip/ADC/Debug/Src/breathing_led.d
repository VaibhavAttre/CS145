Src/breathing_led.o: ../Src/breathing_led.c ../Src/breathing_led.h \
 ../Src/pwm_driver.h
../Src/breathing_led.h:
../Src/pwm_driver.h:
