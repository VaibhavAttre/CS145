################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Src/adc_driver.c \
../Src/breathing_led.c \
../Src/main.c \
../Src/pwm_driver.c \
../Src/syscalls.c \
../Src/sysmem.c 

OBJS += \
./Src/adc_driver.o \
./Src/breathing_led.o \
./Src/main.o \
./Src/pwm_driver.o \
./Src/syscalls.o \
./Src/sysmem.o 

C_DEPS += \
./Src/adc_driver.d \
./Src/breathing_led.d \
./Src/main.d \
./Src/pwm_driver.d \
./Src/syscalls.d \
./Src/sysmem.d 


# Each subdirectory must supply rules for building sources it contributes
Src/%.o Src/%.su Src/%.cyclo: ../Src/%.c Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m33 -std=gnu11 -g3 -DDEBUG -DSTM32H563ZITx -DSTM32 -DSTM32H5 -DNUCLEO_H563ZI -c -I../Inc -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Src

clean-Src:
	-$(RM) ./Src/adc_driver.cyclo ./Src/adc_driver.d ./Src/adc_driver.o ./Src/adc_driver.su ./Src/breathing_led.cyclo ./Src/breathing_led.d ./Src/breathing_led.o ./Src/breathing_led.su ./Src/main.cyclo ./Src/main.d ./Src/main.o ./Src/main.su ./Src/pwm_driver.cyclo ./Src/pwm_driver.d ./Src/pwm_driver.o ./Src/pwm_driver.su ./Src/syscalls.cyclo ./Src/syscalls.d ./Src/syscalls.o ./Src/syscalls.su ./Src/sysmem.cyclo ./Src/sysmem.d ./Src/sysmem.o ./Src/sysmem.su

.PHONY: clean-Src

