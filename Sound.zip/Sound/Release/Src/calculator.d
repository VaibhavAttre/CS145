Src/calculator.o: ../Src/calculator.c
