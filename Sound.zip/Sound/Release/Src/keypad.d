Src/keypad.o: ../Src/keypad.c ../Src/keypad.h
../Src/keypad.h:
