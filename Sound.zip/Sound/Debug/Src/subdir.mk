################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Src/keypad.c \
../Src/main.c \
../Src/pwm_tone.c \
../Src/syscalls.c \
../Src/sysmem.c \
../Src/tones.c 

OBJS += \
./Src/keypad.o \
./Src/main.o \
./Src/pwm_tone.o \
./Src/syscalls.o \
./Src/sysmem.o \
./Src/tones.o 

C_DEPS += \
./Src/keypad.d \
./Src/main.d \
./Src/pwm_tone.d \
./Src/syscalls.d \
./Src/sysmem.d \
./Src/tones.d 


# Each subdirectory must supply rules for building sources it contributes
Src/%.o Src/%.su Src/%.cyclo: ../Src/%.c Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m33 -std=gnu11 -g3 -DDEBUG -DSTM32H563ZITx -DSTM32 -DSTM32H5 -DNUCLEO_H563ZI -c -I../Inc -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Src

clean-Src:
	-$(RM) ./Src/keypad.cyclo ./Src/keypad.d ./Src/keypad.o ./Src/keypad.su ./Src/main.cyclo ./Src/main.d ./Src/main.o ./Src/main.su ./Src/pwm_tone.cyclo ./Src/pwm_tone.d ./Src/pwm_tone.o ./Src/pwm_tone.su ./Src/syscalls.cyclo ./Src/syscalls.d ./Src/syscalls.o ./Src/syscalls.su ./Src/sysmem.cyclo ./Src/sysmem.d ./Src/sysmem.o ./Src/sysmem.su ./Src/tones.cyclo ./Src/tones.d ./Src/tones.o ./Src/tones.su

.PHONY: clean-Src

