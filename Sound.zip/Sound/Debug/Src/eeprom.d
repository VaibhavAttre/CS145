Src/eeprom.o: ../Src/eeprom.c ../Src/eeprom.h
../Src/eeprom.h:
