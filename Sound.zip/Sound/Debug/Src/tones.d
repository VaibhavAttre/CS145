Src/tones.o: ../Src/tones.c ../Src/tones.h
../Src/tones.h:
