Src/main.o: ../Src/main.c ../Src/keypad.h ../Src/pwm_tone.h \
 ../Src/tones.h ../Src/eeprom.h ../Src/mode_leds.h
../Src/keypad.h:
../Src/pwm_tone.h:
../Src/tones.h:
../Src/eeprom.h:
../Src/mode_leds.h:
