Src/main.o: ../Src/main.c ../Src/lcd.h ../Src/keypad.h \
 ../Src/calculator.h
../Src/lcd.h:
../Src/keypad.h:
../Src/calculator.h:
