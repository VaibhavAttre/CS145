Src/calculator.o: ../Src/calculator.c ../Src/lcd.h ../Src/keypad.h \
 ../Src/calculator.h
../Src/lcd.h:
../Src/keypad.h:
../Src/calculator.h:
