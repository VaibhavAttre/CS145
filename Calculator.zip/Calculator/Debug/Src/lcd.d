Src/lcd.o: ../Src/lcd.c ../Src/lcd.h
../Src/lcd.h:
